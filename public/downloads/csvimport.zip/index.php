<?php
include("csvimport-class.php");

$class = new importCSVinDatabase;

$class->readFile = "upload-test.csv"; // File you want to read in
$class->newTableName = "daten-test3"; // Tablename in which you want to import (will be created new)
$class->seperator = ","; // Seperator of the csv. You may wish to confirm, that this symbol is never used in text

$class->rowNamesAsFirstRowInCSV = false; // Are in the first row of the csv the headings?

$class->trimQuotationMarks = true; // Do you want to trim quotation marks?

$class->explodeWithQuotationMarks = true; // If all fields are text and the Seperator is in the text activate this option.
$class->activateEscaping = false; // Do you want to escape the Data? If there are " in the text this can be tricky.

$class->connectToDatabase("localhost", "root", "", "shopdaten"); // host, user, passwort, databasename

$class->build(); // let's start!

?>