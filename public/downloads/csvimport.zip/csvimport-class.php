<?php

/**
* Class to import an CSV in a MySQL-Database
* (Needs PHP Version >= 4.3) 
*
* @copyright: 2010 by David Reess (www.david-reess.de)
* @version: 0.1.2
*
* @todo: Import rows as numbers, if there are only numbers
*/
class importCSVinDatabase{

	/**
   * The file you want to read in
   *
	 * @var string
	 */
	public $readFile;
	
	/**
   * Are in the first row of the csv the headings?
   *
	 * @var boolean
	 */
	public $rowNamesAsFirstRowInCSV = false;
	
	/**
   * Do you want to trim quotation marks?
   *
	 * @var boolean
	 */
	public $trimQuotationMarks = true;
	
	/**
   * Tablename in which you want to import (will be created new)
   *
	 * @var string
	 */
	public $newTableName;
	
	/**
   * Seperator of the csv. You may wish to confirm, that this symbol is never used in text
   *
	 * @var string
	 */
	public $seperator = ";";
  
  /**
   * If all fields are text and the Seperator is in the text activate this option
   *
	 * @var boolean
	 */
	public $explodeWithQuotationMarks = false;
  
  /**
   * Do you want to escape the Data? If there are " in the text this can be tricky.
   *
	 * @var boolean
	 */
  public $activateEscaping = false;

	/**
	 * Sends an MySQL-Query and throws an error, when not successful.
	 * 
	 * @param string $q The Query
	 * @return resource
	 */
	public function query($q){

		$r = mysql_query($q);

		if($r){
			return $r;
		}else{
			$this->msgOut("<h1>Database Error!</h1>
                     Sql: <pre>".htmlentities($q)."</pre> 
                     MySQL-Error: <pre>".mysql_error()."</pre>", true);
			die();
		}

	}

	/**
	 * Connects with the Database
	 * 
	 * @param string $db_host Host of the Database, often localhost
	 * @param string $db_user User of the Databse
	 * @param string $db_password Passwort of the Database
	 * @param string $db_name Name of the Databse
	 */
	public function connectToDatabase($db_host, $db_user, $db_password, $db_name){

		mysql_connect($db_host, $db_user, $db_password) or die($this->msgOut("Can not connect to the database.", true));
		mysql_select_db($db_name) or die($this->msgOut("Database does not exist.", true));

	}
  
  /**
  * Escapes a String if the option is turned on.
  *
  * @param string $s The string you want to escape
  * @return string Escaped String
  */
  public function escape($s){
    if($this->activateEscaping){
      return mysql_real_escape_string($s);
    }
    
    return $s;
  }
  
  /**
  * Removes errors of the query.
  *
  * @param string $s The string you want to clear
  * @return string Clear String
  */
  public function removeErrors($s){
    return str_replace('""', '"', $s);
  }

	/**
	 * The building of the SQL-Statements and importing of the Files.
	 */
	public function build(){

		$this->msgOut("Process started.");
		$this->msgOut("File: ".$this->readFile);
		$this->msgOut("New Tablename: ".$this->newTableName);
		$this->msgOut("Seperator: ".$this->seperator);

		$handle = @fopen($this->readFile, "r");

		if(!$handle){
			$this->msgOut("Error: File does not exist", true);
			return false;
		}

		$allLines = array();

		$i = 1;
    
		while($line = fgets($handle)){
      
      
      if(!$this->explodeWithQuotationMarks){
			  $newArray = explode($this->seperator, $line);
      }else{
        $newArray = explode('"'.$this->seperator.'"', $line);
      }

			$newArray2 = array();

			foreach($newArray as $a){
				if($this->trimQuotationMarks){
					$newArray2[] = trim(trim(trim($a), '"'));
				}else{
					$newArray2[] = trim($a);
				}
			}

			$allLines[] = $newArray2;

			$this->msgOut("Read line $i");
			$i++;
		}

		fclose($handle);
		$this->msgOut("File closed successfully");

		$rows = 0;

		foreach($allLines as $n){
			if($rows < count($n)){
				$rows = count($n);
			}
		}

		$this->msgOut("Rows: $rows");
    
    $this->debug($allLines);


		$sql = "CREATE TABLE `".$this->newTableName."` (";

		$q = 0;
		while($q != $rows){
			$sql .= "`";
			if($this->rowNamesAsFirstRowInCSV){
				$sql .= ($allLines[0][$q] != "") ? $this->escape($allLines[0][$q]) : $q+1;
			}else{
				$sql .= "FIELD";
				$sql .= $q+1;
			}
			$sql .= "` TEXT NOT NULL,";
			$q++;
		}

		$sql = substr($sql, 0, strlen($sql)-1);



		$sql .= ") ENGINE = MYISAM ;";
    
    $sql = $this->removeErrors($sql);

		$this->msgOut("SQL for creating table: <pre>$sql</pre>");
    
    

		$q = $this->query($sql);

		$this->msgOut("Created table successfully!");

		if($this->rowNamesAsFirstRowInCSV){
			$i = 1;
		}else{
			$i = 0;
		}

		$sql = "INSERT INTO `".$this->newTableName."` (";

		$q = 0;
		while($q != $rows){
			$sql .= "`";
			if($this->rowNamesAsFirstRowInCSV){
				$sql .= ($allLines[0][$q] != "") ? $this->escape($allLines[0][$q]) : $q+1;
			}else{
				$sql .= "FIELD";
				$sql .= $q+1;
			}
			$sql .= "`,";
			$q++;
		}

		$sql = substr($sql, 0, strlen($sql)-1);

		$sql .= ") VALUES ";

		for($i = $i; $i != count($allLines); $i++){

			$sql .= "(";

			$q = 0;
			while($q != $rows){
				$sql .= "'".$this->escape($allLines[$i][$q])."',";
				$q++;
			}

			$sql = substr($sql, 0, strlen($sql)-1);

			$sql .= "),";



		}

		$sql = substr($sql, 0, strlen($sql)-1);
		$sql .= ";";
		 
      $sql = $this->removeErrors($sql);
		 
		$this->msgOut("Import started, SQL: <pre>$sql</pre>");
		$q = $this->query($sql);
		$this->msgOut("Import successfully.");

	}

	/**
	 * Shows an message to the user.
	 * 
	 * @param string $m The message you want to show
	 * @param boolean $e It the message an error?
	 */
	public function msgOut($m, $e = false){

		echo ($e) ? '<span style="color: red">'.$m.'</span>'  : $m;
		echo "<br>";
		flush();

	}

	/**
	 * Debugs an variable
	 * 
	 * @param mixed $m The String, Array, etc. you want to debug
	 */
	public function debug($m){

		echo "<pre>";
		var_dump($m);
		echo "</pre>";

	}



}

?>